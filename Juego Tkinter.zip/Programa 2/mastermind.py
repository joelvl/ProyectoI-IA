from os import popen
from random import *
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import pickle

# Inicio Proyecto 1


# ----------------------------------------------------------------------------------------------------------------------


# Datos
lista_contactos = []  # Lista global de los contactos
modif = False  # Variable que indica si un contacto está siendo modificado o no
Temp = []  # Variable que guarda el contacto a modificar por si el usuario desea cancelar la modificacion
directorio = ""  # Variable de la direccion de la imagen del contacto a escoger


# Funciones


def agregar_contacto(lista, tipo, adicional):
    """Función asociada al boton "btnAceptar"
Entradas: La lista cn todos los elementos del contacto a agregar, la variable modif para indicar si se está modificando el contacto y una lista con los datos adicionales
Salidas: Si en la lista contactos no se encuentra el nombre a agregar, lo agrega a la lista de contactos, de lo contrario no se sale de la ventana
Proceso: Pasa por toda la lista revisando el primer elemento de cada contacto(que es donde estan los nombres de los contactos),\
         si el nombre ingresado en la caja de texto es igual a un nombre en la lista de contactos, no lo agrega, de lo contrario lo agrega a la lista de contactos"""

    global lista_contactos
    if tipo is False:  # Variable tipo se refiere si el contacto se está modificando o agregando desde 0.
        esta = False  # Variable esta revisa si el contacto a ingresar se encuentra en la lista.
        for i in lista_contactos:
            if lista_contactos is []:
                lista_contactos += [lista]
            if lista[0] == i[0]:
                esta = True  # Si encuentra una relacion, no lo puede agregar ya que se encuentra en la lista de contactos.
        if esta is False:  # Como no está en la lista de contactos, procede a añadir el contacto.
            if lista[0] == "":
                messagebox.showerror(title="Error", message="Ingrese un nombre al contacto")  # Devuelve un mensaje de error si el nombre está vacío.
            else:
                ad = agrega_adicionales(adicional)  # ad contendrá los datos adicionales del contacto.
                if ad is not []:  # Si los datos adicionales estan vacios, no los agrega, de lo contrario los agrega.
                    lista += [ad]
                color = 0  # Variable para el color que se despliega en el widget lista para una mayor identificación.
                cont = 0  # Lleva el indice para aplicar el color.
                lista_contactos += [lista]  # Añade la sublista del contacto actual.
                lista_contactos.sort()  # Ordena alfabeticamente la lista.
                listbox.delete(0, END)  # Borra los datos del widget lista para ingresar los nuevos contactos.
                for i in lista_contactos:
                    listbox.insert(END, i[0])  # Agrega los contactos de la nueva lista de contactos al widget.
                    if color == 0:  # Alterna los colores de los contactos.
                        listbox.itemconfig(cont, background="sky blue")
                        color = 1
                        cont += 1
                    else:
                        listbox.itemconfig(cont, background="white")
                        color = 0
                        cont += 1
                salir_agregar()
        else:
            messagebox.showerror(title="Error",
                                 message="Este contacto ya está registrado, no se puede agregar")  # Si esta==True devuelve un mensaje de error.
    elif tipo is True:  # Si el contacto está en modificación entra aquí.
        global modif
        modif = False  # Se devuelve el estado del modificador a su valor predefinido. El procedimiento de aqui en adelante es el mismo que conlleva la parte de arriba.
        esta = False
        for i in lista_contactos:
            if lista_contactos is []:
                lista_contactos += [lista]
            if lista[0] == i[0]:
                esta = True
        if esta is False:
            if lista[0] == "":
                messagebox.showerror(title="Error", message="Ingrese un nombre al contacto")
            else:
                ad = agrega_adicionales(adicional)
                if ad is not []:
                    lista += [ad]
                color = 0
                cont = 0
                lista_contactos += [lista]
                lista_contactos.sort()
                listbox.delete(0, END)
                for i in lista_contactos:
                    listbox.insert(END, i[0])
                    if color == 0:
                        listbox.itemconfig(cont, background="sky blue")
                        color = 1
                        cont += 1
                    else:
                        listbox.itemconfig(cont, background="white")
                        color = 0
                        cont += 1
                salir_agregar()
        else:
            messagebox.showerror(title="Error", message="Este contacto ya está registrado, no se puede agregar")


def salir_agregar():
    """Funcion para cancelar a la hora de agregar un contacto
Proceso: Si no se está modificanto, limpia todos los espacios y se devuelve a la ventana de contactos. Si se está modifican, hay que devolver el contacto como estaba, sin modificaciones"""
    ven_contactos.deiconify()
    ven_agregar.withdraw()
    global modif
    global Temp
    global lista_contactos
    global directorio
    global NumCelular
    global NumTrabajo
    global NumCasa
    global NumFax
    global NumOtros
    global CorPersonal1
    global CorPersonal2
    global CorTrabajo1
    global CorTrabajo2
    global CorOtros1
    global CorOtros2
    global Sonido
    global Direccion
    global Trabajo
    global Estudio
    global listbox
    global AdNotas
    global AdFamilia
    global AdProfesión
    global AdCumpleaños
    global AdAniversarioM
    global AdAniversarioT
    global AdDirTrabajo
    global AdEntretenimientos
    global AdDeportes
    if modif is False:  # Si no se está modificando, solo se limpian los cuadros de texto
        Nombre.set("")
        directorio = ""
        NumCelular.set(0)
        NumTrabajo.set(0)
        NumCasa.set(0)
        NumFax.set(0)
        NumOtros.set(0)
        CorPersonal1.set("")
        CorPersonal2.set("")
        CorTrabajo1.set("")
        CorTrabajo2.set("")
        CorOtros1.set("")
        CorOtros2.set("")
        Sonido.set("Silencio")
        Direccion.set("")
        Trabajo.set("")
        Estudio.set("")
        AdNotas.set("")
        AdFamilia.set("")
        AdProfesión.set("")
        AdCumpleaños.set(0)
        AdAniversarioM.set(0)
        AdAniversarioT.set(0)
        AdDirTrabajo.set("")
        AdEntretenimientos.set("")
        AdDeportes.set("")
    elif modif is True:  # Si se está modificando, hay que devolver el contacto como estaba
        modif = False  # Ya no se está modificando, por eso hay que pasarlo a False
        color = 0  # Variable para el color que se despliega en el widget lista para una mayor identificación.
        cont = 0  # Lleva el indice para aplicar el color.
        lista_contactos += [Temp]  # Añade a la lista de contactos el contacto antes de ser modificado
        lista_contactos.sort()  # Ordena alfabeticamente la lista.
        listbox.delete(0, END)  # Borra los datos del widget lista para ingresar los nuevos contactos.
        for i in lista_contactos:
            listbox.insert(END, i[0])  # Agrega los contactos de la nueva lista de contactos al widget.
            if color == 0:  # Alterna los colores de los contactos.
                listbox.itemconfig(cont, background="sky blue")
                color = 1
                cont += 1
            else:
                listbox.itemconfig(cont, background="white")
                color = 0
                cont += 1
        salir_agregar()  # Y vuelve a entrar para limpiar los cuadros de texto


def elimina_contacto(selec):
    """Entradas: Una tupla con el indice del contacto seleccionado en el widget lista
Salidas: Borra el contacto seleccionado de la lista de cotactos"""

    if selec is ():
        messagebox.showerror(title="Error",
                             message="Seleccione un contacto primero")  # Si el usuario no ha seleccionado un contacto, este retorna un mensaje de error ya no se puede realizar la operación.
    else:
        pregunta = messagebox.askokcancel(title="Eliminar contacto",
                                          message="Estas seguro de eliminar a este contacto?")  # Pregunta al usuario si desea confirmar la eliminación del contacto elegido.
        if pregunta is True:  # Si se responde sí la pregunta procede a eliminarlo.
            global lista_contactos
            color = 0  # Variable para el color que se despliega en el widget lista para una mayor identificación.
            cont = 0  # Lleva el indice para aplicar el color.
            lista_contactos = lista_contactos[:selec[0]] + lista_contactos[selec[
                                                                               0] + 1:]  # La variable selec es una tupla, contiene el índice del contacto seleccionado en el widget. Por lo tanto se crea una nueva lista de contactos omitiendo ese índice.
            lista_contactos.sort()  # Ordena alfabeticamente la nueva lista sin el contacto
            listbox.delete(0, END)  # Se borra lo que hay en el widget lista
            for i in lista_contactos:  # Se agrega al widget lista la nueva lista sin el contacto seleccionado
                listbox.insert(END, i[0])
                if color is 0:  # Alterna los colores de los contactos.
                    listbox.itemconfig(cont, background="sky blue")
                    color = 1
                    cont += 1
                else:
                    listbox.itemconfig(cont, background="white")
                    color = 0
                    cont += 1


def modifica_contacto(selec):
    """"Entradas: Una tupla con el indice del contacto seleccionado en el widget lista
Salidas: Modifica la informacion del contacto seleccionado"""

    if selec is ():
        messagebox.showerror(title="Error",
                             message="Seleccione un contacto primero")  # Si el usuario no ha seleccionado un contacto, este retorna un mensaje de error ya no se puede realizar la operación.
    else:
        global Temp
        global modif
        global lista_contactos
        global directorio
        global NumCelular
        global NumTrabajo
        global NumCasa
        global NumFax
        global NumOtros
        global CorPersonal1
        global CorPersonal2
        global CorTrabajo1
        global CorTrabajo2
        global CorOtros1
        global CorOtros2
        global Sonido
        global Direccion
        global Trabajo
        global Estudio
        global AdNotas
        global AdFamilia
        global AdProfesión
        global AdCumpleaños
        global AdAniversarioM
        global AdAniversarioT
        global AdDirTrabajo
        global AdEntretenimientos
        global AdDeportes
        Temp = lista_contactos[selec[0]]  # Añade el contacto a una variable externa por si se cancela la operación
        modif = True  # El modificador indica si el contacto está siendo modificado, por lo tanto se le dice que sí (True)

        # Se procede a colocar en todas las cajas de texto de la ventana para agregar el contacto, la información de la lista de contactos que tiene el contacto seleccionado
        Nombre.set(lista_contactos[selec[0]][0])
        directorio = lista_contactos[selec[0]][1]  # Se agrega la ruta de la imagen agregada
        NumCelular.set(lista_contactos[selec[0]][2][0][1])
        NumTrabajo.set(lista_contactos[selec[0]][2][1][1])
        NumCasa.set(lista_contactos[selec[0]][2][2][1])
        NumFax.set(lista_contactos[selec[0]][2][3][1])
        NumOtros.set(lista_contactos[selec[0]][2][4][1])
        if separa_correo1(lista_contactos[selec[0]][3][0][1]) is not None:
            CorPersonal1.set(separa_correo1(lista_contactos[selec[0]][3][0][1]))
            CorPersonal2.set(separa_correo2(lista_contactos[selec[0]][3][0][1]))
        else:
            CorPersonal1.set("")
            CorPersonal2.set("")
        if separa_correo1(lista_contactos[selec[0]][3][1][1]) is not None:
            CorTrabajo1.set(separa_correo1(lista_contactos[selec[0]][3][1][1]))
            CorTrabajo2.set(separa_correo2(lista_contactos[selec[0]][3][1][1]))
        else:
            CorTrabajo1.set("")
            CorTrabajo2.set("")
        if separa_correo1(lista_contactos[selec[0]][3][2][1]) is not None:
            CorOtros1.set(separa_correo1(lista_contactos[selec[0]][3][2][1]))
            CorOtros2.set(separa_correo2(lista_contactos[selec[0]][3][2][1]))
        else:
            CorOtros1.set("")
            CorOtros2.set("")
        Sonido.set(lista_contactos[selec[0]][4])
        Direccion.set(lista_contactos[selec[0]][5])
        Trabajo.set(lista_contactos[selec[0]][6])
        Estudio.set(lista_contactos[selec[0]][7])
        try:
            if isinstance(lista_contactos[selec[0]][8],
                          list):  # Si el contacto tiene datos adicionales, procede a buscar que datos debe agregar a las cajas de texto
                for i in lista_contactos[selec[0]][8]:  # Al contacto, los datos adicionales se agregan como listas anidadas de otra lista (otra lista = el índice 8) y el primer índice de cada lista anidada es la palabra que identifica el tipo de dato.
                    if i[0] == "Notas":
                        AdNotas.set(i[1])
                    elif i[0] == "Familia":
                        AdFamilia.set(i[1])
                    elif i[0] == "Profesión":
                        AdProfesión.set(i[1])
                    elif i[0] == "Cumpleaños":
                        AdCumpleaños.set(i[1])
                    elif i[0] == "Aniversario Matrimonio":
                        AdAniversarioM.set(i[1])
                    elif i[0] == "Aniversario Trabajo":
                        AdAniversarioT.set(i[1])
                    elif i[0] == "Direccion física del trabajo":
                        AdDirTrabajo.set(i[1])
                    elif i[0] == "Entretenimientos":
                        AdEntretenimientos.set(i[1])
                    elif i[0] == "Deportes":
                        AdDeportes.set(i[1])
        except IndexError:
            pass
        lista_contactos = lista_contactos[:selec[0]] + lista_contactos[selec[
                                                                           0] + 1:]  # Elimina el contacto seleccionado de la lista para agregarlo como nuevo y que no haya problema con dejarlo el mismo nombre.
        mostrar_agregar()  # Se muestra la ventana con los datos del usuario


def informacion(selec):
    """Entradas: Una tupla con el indice del contacto seleccionado en el widget lista
Salidas: Despliega la información del contacto seleccionado en la ventana ven_info"""

    if selec == ():
        messagebox.showerror(title="Error",
                             message="Seleccione un contacto primero")  # Si el usuario no ha seleccionado un contacto, este retorna un mensaje de error ya no se puede realizar la operación.
    else:
        Label(ven_info, width=1000, height=1000).place(y=0, x=0)  # Etiqueta en blanco que limpia la ventana
        global lista_contactos
        global ImgDefault
        result = ""  # Almacena los datos del contacto que no sean vacíos para desplegarlo al final
        if lista_contactos[selec[0]][1] != "":
            imagen_contacto = PhotoImage(file=lista_contactos[selec[0]][1])  # Si tiene una ruta de una imagen, la carga
            lblimagen = Label(ven_info, height=50, width=50, image=imagen_contacto)  # y la agrega a una etiqueta
            lblimagen.grid(row=0, column=1)
        else:
            lblimagen = Label(ven_info, height=50, width=50, image=ImgDefault)  # Si no tiene una ruta deja una imagen por defecto(default.png)
            lblimagen.grid(row=0, column=1)
        # Se procede a preguntar si los valores son diferentes a los que están por defecto para agregarlos a la variable
        result += "Nombre del contacto: " + lista_contactos[selec[0]][0] + "\n"  # Es un dato que nunca va a faltar
        if lista_contactos[selec[0]][2][0][1] != 0:
            result += "Número de Celular: " + str(lista_contactos[selec[0]][2][0][1]) + "\n"
        if lista_contactos[selec[0]][2][1][1] != 0:
            result += "Número de Trabajo: " + str(lista_contactos[selec[0]][2][1][1]) + "\n"
        if lista_contactos[selec[0]][2][2][1] != 0:
            result += "Número de la Casa: " + str(lista_contactos[selec[0]][2][2][1]) + "\n"
        if lista_contactos[selec[0]][2][3][1] != 0:
            result += "Fax: " + str(lista_contactos[selec[0]][2][3][1]) + "\n"
        if lista_contactos[selec[0]][2][4][1] != 0:
            result += "Otro Número: " + str(lista_contactos[selec[0]][2][4][1]) + "\n"
        if lista_contactos[selec[0]][3][0][1] is not None:
            result += "Correo personal: " + lista_contactos[selec[0]][3][0][1] + "\n"
        if lista_contactos[selec[0]][3][1][1] is not None:
            result += "Correo de Trabajo: " + lista_contactos[selec[0]][3][1][1] + "\n"
        if lista_contactos[selec[0]][3][2][1] is not None:
            result += "Correo de Trabajo: " + lista_contactos[selec[0]][3][2][1] + "\n"
        result += "Sonido de notificación: " + lista_contactos[selec[0]][4] + "\n"  # Es un dato que nunca va a faltar
        if lista_contactos[selec[0]][5] != "":
            result += "Dirección de la Casa: " + lista_contactos[selec[0]][5] + "\n"
        if lista_contactos[selec[0]][6] != "":
            result += "Lugar de Trabajo: " + lista_contactos[selec[0]][6] + "\n"
        if lista_contactos[selec[0]][7] != "":
            result += "Lugar de Estudio: " + lista_contactos[selec[0]][7] + "\n"
        try:
            if isinstance(lista_contactos[selec[0]][8], list):
                for i in lista_contactos[selec[0]][8]:
                    if i[0] == "Notas":
                        result += "Notas del Contacto: " + i[1] + "\n"
                    elif i[0] == "Familia":
                        result += "Información de la Familia: " + i[1] + "\n"
                    elif i[0] == "Profesión":
                        result += "Profesión: " + i[1] + "\n"
                    elif i[0] == "Cumpleaños":
                        result += "Fecha de Cumpleaños: " + str(i[1]) + "\n"
                    elif i[0] == "Aniversario Matrimonio":
                        result += "Aniversario de Matrimonio: " + str(i[1]) + "\n"
                    elif i[0] == "Aniversario Trabajo":
                        result += "Aniversario de Trabajo: " + str(i[1]) + "\n"
                    elif i[0] == "Direccion física del trabajo":
                        result += "Direccion física del trabajo: " + i[1] + "\n"
                    elif i[0] == "Entretenimientos":
                        result += "Entretenimientos: " + i[1] + "\n"
                    elif i[0] == "Deportes":
                        result += "Deportes: " + i[1] + "\n"
        except IndexError:
            pass
        Label(ven_info, text=result).grid(row=1, column=1)  # Despliega la información del contacto
        mostrar_v_info()  # Muestra la ventana en la que se despliega la información
        ven_info.mainloop()


def agregar_imagen():
    """
Función asociada al boton "btnAgregarImg"
Proceso: Se abre el buscador de archivos y guarga la ruta en una variable"""
    global directorio
    file = filedialog.askopenfilename()  # Abre el buscador de archivos y lo guarda en una variable
    directorio = file  # Se guarda esa ruta en la variable global directorio


def agregar_numeros():
    """
Función asocida a los radiobuttons de numeros de teléfono"""
    s = seleccion_numeros.get()  # La variable s va a ser el valor que tiene el radiobutton actual, busca que número es y despliega la caja de texto asociada a esa variable
    if s == 1:
        global NumCelular
        Entry(ven_agregar, textvariable=NumCelular, width=20).place(x=200, y=65)  # Despliega la caja de texto para la variable NumCelular
    elif s == 2:
        global NumTrabajo
        Entry(ven_agregar, textvariable=NumTrabajo, width=20).place(x=200, y=65)  # Despliega la caja de texto para la variable NumTrabajo
    elif s == 3:
        global NumCasa
        Entry(ven_agregar, textvariable=NumCasa, width=20).place(x=200, y=65)  # Despliega la caja de texto para la variable NumCasa
    elif s == 4:
        global NumFax
        Entry(ven_agregar, textvariable=NumFax, width=20).place(x=200, y=65)  # Despliega la caja de texto para la variable NumFax
    elif s == 5:
        global NumOtros
        Entry(ven_agregar, textvariable=NumOtros, width=20).place(x=200, y=65)  # Despliega la caja de texto para la variable NumOtros


def agregar_correo():
    """Función asocida a los radiobuttons de correos
Salida: Muestra los cuadros de texto asociados a cada radiobutton"""

    s = seleccion_correo.get()  # La variable s va a ser el valor que tiene el radiobutton actual, busca que número es y despliega la caja de texto asociada a esa variable
    if s == 1:
        global CorPersonal1
        global CorPersonal2
        Entry(ven_agregar, textvariable=CorPersonal1, width=18).place(x=200, y=195)  # Despliega las caja de texto para las variables CorPersonal1 y CorPersonal2
        Entry(ven_agregar, textvariable=CorPersonal2, width=18).place(x=340, y=195)
        Label(ven_agregar, text="@", font=("Tahoma", 12)).place(x=315, y=190)  # Despliega la etiqueta del @
    elif s == 2:
        global CorTrabajo1
        global CorTrabajo2
        Entry(ven_agregar, textvariable=CorTrabajo1, width=18).place(x=200, y=195)  # Despliega las caja de texto para las variables CorTrabajo1 y CorTrabajo2
        Entry(ven_agregar, textvariable=CorTrabajo2, width=18).place(x=340, y=195)
        Label(ven_agregar, text="@", font=("Tahoma", 12)).place(x=315, y=190)  # Despliega la etiqueta del @
    elif s == 3:
        global CorOtros1
        global CorOtros2
        Entry(ven_agregar, textvariable=CorOtros1, width=18).place(x=200, y=195)  # Despliega las caja de texto para las variables CorOtros1 y CorOtros2
        Entry(ven_agregar, textvariable=CorOtros2, width=18).place(x=340, y=195)
        Label(ven_agregar, text="@", font=("Tahoma", 12)).place(x=315, y=190)  # Despliega la etiqueta del @


def separa_correo1(correo):
    """
Funcion asociada a modificar
Entradas: Un string que contiene el correo del contacto
Salida: Retorna la primera parte del correo (lo que está antes del @)"""
    if correo is not None:  # None es el valor por defecto que tiene el correo si no se cumple con las restricciones (el correo debe tener algo antes y después del @)
        result = ""
        i = 0
        for i in range(0, len(correo)):
            if correo[i] == "@":  # Cuando encuentre el @, se sale del for\n
                break
        result += correo[:i]  # añade lo que está desde el inicio hasta el arroba (sin contar el arroba),\n
        return result  # y lo retorna
    return None


def separa_correo2(correo):
    """Funcion asociada a modificar
Entradas: Un string que contiene el correo del contacto
Salida: Retorna la segunda parte del correo (lo que está después del @)"""

    if correo is not None:  # None es el valor por defecto que tiene el correo si no se cumple con las restricciones (el correo debe tener algo antes y después del @)
        result = ""
        i = 0
        for i in range(0, len(correo)):
            if correo[i] == "@":  # Cuando encuentre el @, se sale del for\n
                break
        result += correo[i + 1:]  # añade lo que está después del arroba hasta el final,\n
        return result  # y lo retorna
    return None


def datos_adicionales():
    """Función asocida a los radiobuttons de datos adicionales
Salida: Muestra los cuadros de texto asociados a cada radiobutton"""

    s = seleccion_adicional.get()  # La variable s va a ser el valor que tiene el radiobutton actual, busca que número es y despliega la caja de texto asociada a esa variable
    if s == 1:
        global AdNotas
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdNotas, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdNotas
        Label(ven_agregar, text="Min carácteres: 1 | Máx carácteres: 140", font=("Arial", 10)).place(x=25, y=585)
    if s == 2:
        global AdFamilia
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdFamilia, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdFamilia
        Label(ven_agregar, text="Min carácteres: 1 | Máx carácteres: 140", font=("Arial", 10)).place(x=25, y=585)
    if s == 3:
        global AdProfesión
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdProfesión, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdProfesión
        Label(ven_agregar, text="Min carácteres: 3 | Máx carácteres: 50", font=("Arial", 10)).place(x=25, y=585)
    if s == 4:
        global AdCumpleaños
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdCumpleaños, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdCumpleaños
        Label(ven_agregar, text="Formato de 8 dígitos (ddmmaaaa)\nDia(dd), Mes(mm), Año(aaaa)\nAño mayor o igual a 1900", font=("Arial", 10)).place(x=25, y=585)
    if s == 5:
        global AdAniversarioM
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdAniversarioM, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdAniversarioM
        Label(ven_agregar, text="Formato de 8 dígitos (ddmmaaaa)\nDia(dd), Mes(mm), Año(aaaa)\nAño mayor o igual a 1900", font=("Arial", 10)).place(x=25, y=585)
    if s == 6:
        global AdAniversarioT
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdAniversarioT, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdAniversarioT
        Label(ven_agregar, text="Formato de 8 dígitos (ddmmaaaa)\nDia(dd), Mes(mm), Año(aaaa)\nAño mayor o igual a 1900", font=("Arial", 10)).place(x=25, y=585)
    if s == 7:
        global AdDirTrabajo
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdDirTrabajo, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdDirTrabajo
        Label(ven_agregar, text="Min carácteres: 3 | Máx carácteres: 50", font=("Arial", 10)).place(x=25, y=585)
    if s == 8:
        global AdEntretenimientos
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdEntretenimientos, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdEntretenimientos
        Label(ven_agregar, text="Min carácteres: 1 | Máx carácteres: 140", font=("Arial", 10)).place(x=25, y=585)
    if s == 9:
        global AdDeportes
        Label(ven_agregar, width=50, height=50).place(x=25, y=585)  # Etiqueta en blanco que limpia la ventana
        Entry(ven_agregar, textvariable=AdDeportes, width=75).place(x=25, y=565)  # Despliega la caja de texto para la variable AdDeportes
        Label(ven_agregar, text="Min carácteres: 1 | Máx carácteres: 140", font=("Arial", 10)).place(x=25, y=585)


def agrega_adicionales(lista):
    """
Función auxiliar a agregar_contacto
Entrada: Una lista con los datos adicionales del contacto
Salidas: Retorna una lista con sublistas, cada sublista agregado va a tener un nombre para identificarlo y su valor respectivo"""
    result = []  # Variable para retornar la lista con las sublistas
    cont = 1  # Es un índice para saber que tipo de elemento es el que se va a agregar
    for i in lista:
        if i != "":  # Si son diferentes de un string vacio, hay información que agregar
            if cont is 1:
                result += [["Notas", valida_1_140(
                    i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 2:
                result += [["Familia", valida_1_140(
                    i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 3:
                if valida_3_50(i) is "":
                    pass
                else:
                    result += [["Profesión", valida_3_50(
                        i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 4:
                if valida_fecha(i) is True:
                    result += [["Cumpleaños",
                                i]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 5:
                if valida_fecha(i) is True:
                    result += [["Aniversario Matrimonio",
                                i]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 6:
                if valida_fecha(i) is True:
                    result += [["Aniversario Trabajo",
                                i]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 7:
                if valida_3_50(i) is "":
                    pass
                else:
                    result += [["Direccion física del trabajo", valida_3_50(
                        i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 8:
                result += [["Entretenimientos", valida_1_140(
                    i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
            elif cont is 9:
                result += [["Deportes", valida_1_140(
                    i)]]  # Agrega el tipo de elemento y su información respectiva a la variable result
                cont += 1
                continue
        else:
            cont += 1
    return result  # Y lo retorna


def abrir_manual():
    """
Salidas: Abre el manual de usuario de la aplicación"""
    popen("Sergio Hidalgo Fonseca - Manual de usuario libro contactos.pdf")  # Abre el pdf con el manual de usuario


def acerca_de():
    messagebox.showinfo(title="Acerda del programa",
                        message="Contactos\nVersión: 1.0.2\nFecha de creación: 20 de Setiembre, 2016\nAutor: Sergio Hidalgo Fonseca")  # Despliega un mensaje con la infromacion de la aplicación


# Funciones que Validan datos
def pegar_correo(part1, part2):
    """
Entradas: El primer y segundo cuadro de texto del correo
Salidas: Las dos partes juntas con el @"""
    if part1 != "" and part2 != "":  # Valida que tenga las dos partes antes de poder agregar el correo
        x = part1 + "@" + part2
        return x


def direccion():
    """
Función de validación de la entrada de Direccion de la casa
Salidas: Un string entre 0 y 50 carácteres"""
    x = Direccion.get()  # Obtiene lo que tiene el cuadro de texto Direccion
    largo = len(x)
    if largo < 50:  # Si el largo del string no supera los 50 carácteres, lo retrona
        return x
    result = ""
    for i in range(0, 50):  # Si tiene más, no importa cuantas tenga, agrega solo 50 y lo retorna
        result += x[i]
    return result


def trabajo():
    """
Función de validación de la entrada de Lugar de Trabajo
Salidas: Un string entre 0 y 50 carácteres"""
    x = Trabajo.get()  # Obtiene lo que tiene el cuadro de texto Trabajo
    largo = len(x)
    if largo < 50:  # Si el largo del string no supera los 50 carácteres, lo retrona
        return x
    result = ""
    for i in range(0, 50):  # Si tiene más, no importa cuantas tenga, agrega solo 50 y lo retorna
        result += x[i]
    return result


def estudio():
    """
Función de validación de la entrada de Lugar de Estudio
Salidas: Un string entre 0 y 50 carácteres"""
    x = Estudio.get()  # Obtiene lo que tiene el cuadro de texto Estudio
    result = ""
    largo = len(x)
    if largo < 50:  # Si el largo del string no supera los 50 carácteres, lo retrona
        return x
    for i in range(0, 50):  # Si tiene más, no importa cuantas tenga, agrega solo 50 y lo retorna
        result += x[i]
    return result


def valida_1_140(string):
    """
Función auxiliar a la funcion agrega_adicionales
Entradas: Un string a validar
Salidas: Un string entre 0 y 140 carácteres"""
    result = ""
    largo = len(string)
    if largo < 140:  # Si el largo del string no supera los 140 carácteres, lo retrona
        return string
    for i in range(0, 140):  # Si tiene más, no importa cuantas tenga, agrega solo 140 y lo retorna
        result += string[i]
    return result


def valida_3_50(string):
    """
Función auxiliar a la funcion agrega_adicionales
Entradas: Un string a validar
Salidas: Un string entre 3 y 50 carácteres"""
    result = ""
    largo = len(string)
    if largo < 3:  # Si el largo del string no supera los 3 carácteres, retorna vacio ya que 3 es el mínimo
        return ""
    elif largo < 50:  # Si el largo del string no supera los 50 carácteres, lo retrona
        return string
    for i in range(0, 50):  # Si tiene más, no importa cuantas tenga, agrega solo 50 y lo retorna
        result += string[i]
    return result


def valida_fecha(ddmmaaaa):
    """
Entradas: Un número de 8 dígitos con el formato ddmmaaaa (Dia, Mes y Año respectivamente)
Salidas: Retorna valor booleano si la fecha ingresada es válida
Restricciones: El año debe ser mayor a 1900 y el numero debe ser positivo"""
    ano = ddmmaaaa % 10000
    mes = (ddmmaaaa // 10000) % 100
    dia = ddmmaaaa // 1000000
    if ano >= 1900:  # Restriccion
        if mes == 2:
            if ano % 4 == 0 and 0 < dia < 30:
                return True
            elif ano % 4 != 0 and 0 < dia < 29:
                return True
            return False
        elif mes == 11 or mes == 4 or mes == 6 or mes == 9 and 1 <= dia <= 30:
            return True
        elif mes == 1 or mes == 3 or mes == 5 or mes == 7 or mes == 8 or mes == 10 or mes == 12 and 1 <= dia <= 31:
            return True
        return False
    return False


# Interfáz gráfica

# Mostrar y Ocultar ventanas

def cerrar_todo():
    ven_principal.destroy()


def mostrar_v_contactos():
    """
Salidas: Muestra la ventana del lirbo de contactos y esconde la principal"""
    ven_contactos.deiconify()  # Despliega la ventana
    ven_principal.withdraw()  # Oculta la ventana


def regresar_a_ventana():
    """
Salidas: Muestra la ventana principal y esconde la del libro de contactos"""
    ven_principal.deiconify()  # Despliega la ventana
    ven_contactos.withdraw()  # Oculta la ventana
    ven_mm.withdraw()


def mostrar_agregar():
    """
Salidas: Muestra la ventana para agregar un contacto y esconde la del libro de contactos"""
    ven_agregar.deiconify()  # Despliega la ventana
    ven_contactos.withdraw()  # Oculta la ventana


def mostrar_v_info():
    """Salidas: Coloca el boton para regresar, muestra la ventana de infromación de un contacto y esconde la del libro de conttactos"""
    Button(ven_info, image=ImgRegresar, command=regresar_a_contactos).grid(row=0, column=0)  # Agrega el boton a la ventana de la información del contacto para poder regresar
    ven_info.deiconify()  # Despliega la ventana
    ven_contactos.withdraw()  # Oculta la ventana


def regresar_a_contactos():
    """
Salidas: Muestra la ventana del libro de contactos y esconde la de informacion de un contacto"""
    ven_contactos.deiconify()  # Despliega la ventana
    ven_info.withdraw()  # Oculta la ventana


# Ventana principal
ven_principal = Tk()
ven_principal.geometry("372x720+400+200")
ven_principal.title("Menú principal del teléfono")

# Ventana de contactos
ven_contactos = Toplevel(ven_principal)
ven_contactos.geometry("372x720+400+200")
ven_contactos.title("Contactos")
ven_contactos.protocol("WM_DELETE_WINDOW", cerrar_todo)

# Ventana de agregar
ven_agregar = Toplevel(ven_principal)
ven_agregar.geometry("500x700+350+250")
ven_agregar.title("Agregar contacto")
ven_agregar.protocol("WM_DELETE_WINDOW", cerrar_todo)

# Ventana que despliega la información del contacto
ven_info = Toplevel(ven_principal)
ven_info.geometry("1050x420+400+200")
ven_info.title("Información del contacto")
ven_info.protocol("WM_DELETE_WINDOW", cerrar_todo)

# Cargar imagenes
ImgContactos = PhotoImage(file="contactos.gif")
ImgAceptar = PhotoImage(file="aceptar.gif")
ImgCancelar = PhotoImage(file="cancelar.gif")
ImgAgregar = PhotoImage(file="agregar.gif")
ImgEliminar = PhotoImage(file="eliminar.gif")
ImgInformacion = PhotoImage(file="informacion.gif")
ImgModificar = PhotoImage(file="modificar.gif")
ImgRegresar = PhotoImage(file="regresar.gif")
ImgBackground = PhotoImage(file="celular.png")
ImgDefault = PhotoImage(file="default.png")

# Fondos y Etiquetas
lblbackground_ventana = Label(ven_principal, image=ImgBackground).place(x=0, y=0)
lblbackground_v_contactos = Label(ven_contactos, image=ImgBackground).place(x=0, y=0)

Label(ven_principal, text="Contactos", fg="brown", bg="sky blue", font=("Tahoma", 14)).place(x=145, y=560)
Label(ven_agregar, text="Nombre del contacto:", font=("Tahoma", 12)).place(x=30, y=10)
Label(ven_agregar, text="Números de Teléfono:", font=("Tahoma", 12)).place(x=30, y=65)
Label(ven_agregar, text="Correos Electrónicos:", font=("Tahoma", 12)).place(x=30, y=190)
Label(ven_agregar, text="Sonido de notificación:", font=("Tahoma", 12)).place(x=30, y=280)
Label(ven_agregar, text="Dirección de la casa:", font=("Tahoma", 12)).place(x=30, y=320)
Label(ven_agregar, text="Lugar de Trabajo:", font=("Tahoma", 12)).place(x=30, y=360)
Label(ven_agregar, text="Lugar de Estudio:", font=("Tahoma", 12)).place(x=30, y=400)
Label(ven_agregar, text="Límite de carácteres: 50", font=("Arial", 8)).place(x=345, y=342)
Label(ven_agregar, text="Límite de carácteres: 50", font=("Arial", 8)).place(x=345, y=382)
Label(ven_agregar, text="Límite de carácteres: 50", font=("Arial", 8)).place(x=345, y=422)
Label(ven_agregar, text="Nota: La imagen no puede\nser muy grande (en píxeles)", font=("Arial", 8)).place(x=340, y=90)
Label(ven_agregar, text="Sugerencia: No cargar imágenes con\ndimensiones mayores a 300x300 píxeles.", font=("Arial", 8)).place(x=295, y=120)
lblDatosAd = Label(ven_agregar, text="Datos Adicionales", font=("Tahoma", 12)).place(x=30, y=450)

# Cuadros de texto
Nombre = StringVar()
txtNombre = Entry(ven_agregar, textvariable=Nombre, width=40).place(x=190, y=15)
Direccion = StringVar()
txtDireccion = Entry(ven_agregar, textvariable=Direccion, width=45).place(x=190, y=325)
Trabajo = StringVar()
txtTrabajo = Entry(ven_agregar, textvariable=Trabajo, width=45).place(x=190, y=365)
Estudio = StringVar()
txtEstudio = Entry(ven_agregar, textvariable=Estudio, width=45).place(x=190, y=405)

# Variables para cuadros de texto
NumCelular = IntVar()
NumCasa = IntVar()
NumFax = IntVar()
NumTrabajo = IntVar()
NumOtros = IntVar()
CorPersonal1 = StringVar()
CorPersonal2 = StringVar()
CorTrabajo1 = StringVar()
CorTrabajo2 = StringVar()
CorOtros1 = StringVar()
CorOtros2 = StringVar()
AdNotas = StringVar()
AdFamilia = StringVar()
AdProfesión = StringVar()
AdCumpleaños = IntVar()
AdAniversarioM = IntVar()
AdAniversarioT = IntVar()
AdDirTrabajo = StringVar()
AdEntretenimientos = StringVar()
AdDeportes = StringVar()

# Combos(Spinbox)
Sonido = StringVar()
spnSonidos = Spinbox(ven_agregar, values=("Silencio", "Soft", "Guitar", "Waterfall", "Sunshine", "Moonlight"),
                     state="readonly", textvariable=Sonido).place(x=205, y=285)

# Radiobuttons
seleccion_numeros = IntVar()
rdBCelular = Radiobutton(ven_agregar, text="Número de celular", value=1, variable=seleccion_numeros,
                         command=agregar_numeros).place(x=30, y=85)
rdBTrabajo = Radiobutton(ven_agregar, text="Número del Trabajo", value=2, variable=seleccion_numeros,
                         command=agregar_numeros).place(x=30, y=105)
rdBCasa = Radiobutton(ven_agregar, text="Número de la casa", value=3, variable=seleccion_numeros,
                      command=agregar_numeros).place(x=30, y=125)
rdBFax = Radiobutton(ven_agregar, text="Número de Fax", value=4, variable=seleccion_numeros,
                     command=agregar_numeros).place(x=30, y=145)
rdBOtros = Radiobutton(ven_agregar, text="Otros", value=5, variable=seleccion_numeros, command=agregar_numeros).place(
    x=30, y=165)

seleccion_correo = IntVar()
rdBPersonal = Radiobutton(ven_agregar, text="Personal", value=1, variable=seleccion_correo,
                          command=agregar_correo).place(x=30, y=215)
rdBCTrabajo = Radiobutton(ven_agregar, text="Trabajo", value=2, variable=seleccion_correo,
                          command=agregar_correo).place(
    x=30, y=235)
rdBCOtros = Radiobutton(ven_agregar, text="Otros", value=3, variable=seleccion_correo, command=agregar_correo).place(
    x=30, y=255)

seleccion_adicional = IntVar()
rdBNotas = Radiobutton(ven_agregar, text="Notas", value=1, variable=seleccion_adicional,
                       command=datos_adicionales).place(x=30, y=480)
rdBFamilia = Radiobutton(ven_agregar, text="Familia", value=2, variable=seleccion_adicional,
                         command=datos_adicionales).place(x=90, y=480)
rdBProfesion = Radiobutton(ven_agregar, text="Profesión", value=3, variable=seleccion_adicional,
                           command=datos_adicionales).place(x=160, y=480)
rdBCumpleaños = Radiobutton(ven_agregar, text="Fecha de\nCumpleaños", value=4, variable=seleccion_adicional,
                            command=datos_adicionales).place(x=240, y=472)
rdBAniversarioM = Radiobutton(ven_agregar, text="Aniversario del\nMatrimonio", value=5, variable=seleccion_adicional,
                              command=datos_adicionales).place(x=350, y=472)
rdBAniversarioT = Radiobutton(ven_agregar, text="Aniversario\ndel Trabajo", value=6, variable=seleccion_adicional,
                              command=datos_adicionales).place(x=30, y=510)
rdBDirTrabajo = Radiobutton(ven_agregar, text="Direccion física\ndel trabajo", value=7, variable=seleccion_adicional,
                            command=datos_adicionales).place(x=130, y=510)
rdBEntretenimientos = Radiobutton(ven_agregar, text="Entretenimientos", value=8, variable=seleccion_adicional,
                                  command=datos_adicionales).place(x=250, y=517)
rdBDeportes = Radiobutton(ven_agregar, text="Deportes", value=9, variable=seleccion_adicional,
                          command=datos_adicionales).place(x=375, y=517)

# Lista de contactos y scrollbar
scrollbar = Scrollbar(ven_contactos)
scrollbar.pack(side=RIGHT, fill=Y)
listbox = Listbox(ven_contactos, height=24, width=48)
listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)
listbox.place(x=40, y=175)

# Botones
btnContactos = Button(ven_principal, image=ImgContactos, command=mostrar_v_contactos).place(x=160, y=500)
btnRegresar = Button(ven_contactos, image=ImgRegresar, command=regresar_a_ventana).place(x=30, y=115)
btnAgregar = Button(ven_contactos, image=ImgAgregar, command=mostrar_agregar).place(x=95, y=115)
btnElimminar = Button(ven_contactos, image=ImgEliminar, command=lambda: elimina_contacto(listbox.curselection())).place(x=160, y=115)
btnModificar = Button(ven_contactos, image=ImgModificar, command=lambda: modifica_contacto(listbox.curselection())).place(x=225, y=115)
btnInformacion = Button(ven_contactos, image=ImgInformacion, command=lambda: informacion(listbox.curselection())).place(x=290, y=115)
btnAgregarImg = Button(ven_agregar, text="Agregar Imagen", command=agregar_imagen).place(x=360, y=60)
btnCancelar = Button(ven_agregar, image=ImgCancelar, command=salir_agregar).place(x=440, y=640)
btnAceptar = Button(ven_agregar, image=ImgAceptar, command=lambda: agregar_contacto([Nombre.get(), directorio, [("Celular", NumCelular.get()), ("Trabajo", NumTrabajo.get()), ("Casa", NumCasa.get()), ("Fax", NumFax.get()), ("Otros", NumOtros.get())], [("Personal", pegar_correo(CorPersonal1.get(), CorPersonal2.get())), ("Trabajo", pegar_correo(CorTrabajo1.get(), CorTrabajo2.get())), ("Otros", pegar_correo(CorOtros1.get(), CorOtros2.get()))], Sonido.get(), direccion(), trabajo(), estudio()], modif, [AdNotas.get(), AdFamilia.get(), AdProfesión.get(), AdCumpleaños.get(), AdAniversarioM.get(), AdAniversarioT.get(), AdDirTrabajo.get(), AdEntretenimientos.get(), AdDeportes.get()])).place(x=380, y=640)
btnAyuda = Button(ven_contactos, text="Ayuda", command=abrir_manual).place(x=50, y=565)
btnAcercaDe = Button(ven_contactos, text="Acerca de", command=acerca_de).place(x=110, y=565)

ven_contactos.withdraw()  # Oculta ventana
ven_agregar.withdraw()
ven_info.withdraw()

# ----------------------------------------------------------------------------------------------------------------------


# Fin Proyecto 1


# Inicio Proyecto 2


# ----------------------------------------------------------------------------------------------------------------------


# Datos
codigo = ""  # Almacena el código a adivinar creado aleatoriamente
otros_codigos = []  # Evita que los codigos se repitan
cont_codigos = 0  # Cuando llegue a 100 se reinician las apariciones aleatorias
intento = ["", "", "", ""]  # Contiene la jugada actual a calificar
numero_de_jugada = 2  # Leva la cuenta del numero de jugada
opciones = '123456'  # Opciones para crear el código
coincidencias = 0  # Contadores de las jugadas
apariciones = 0
segs = 0  # Variables para el reloj
mins = 0
hora = 0
terminar = False  # Variable que termina el juego si se excede el tiempo ingresado
temp = 0  # Almacena la cantidad de segundos transcurridos 
segundos_config = 0  #Contendria los segundos sacados del archivos


# Funciones
def iniciar():
    """
Salidas: Despliega en la pantalla todo lo necesario para el juego seleccionado de acuerdo con la configuracion ingresada e inicializa el juego"""
    global tiempo, nombre, jugada_max, vdificultad, tablero
    cargar_configuracion()
    if jugador.get() == "":  # No inicia el juego si no ha ingresado un nombre para jugar
        messagebox.showerror(title="Error", message="Primero ingrese un nombre para poder jugar")
    else:
        nombre = jugador.get()  # Guarda el nombre del jugador y no puede ser modificado en media partida
        # Botones del juego
        Button(ven_juego, text="Finalizar Juego", bg="green", font=("Tahoma", 14), command=boton_fin).place(x=220, y=600)  # Boton finalizar partida
        Button(ven_juego, text="Calificar", bg="sky blue", font=("Tahoma", 14), command=calificar).place(x=255, y=550)  # Boton para Calificar las jugadas
        if vdificultad == 1:  # Condicional para verificar el nivel de dificultad y la cantidad de jugadas posibles
            jugada_max = 9
        elif vdificultad == 2:
            jugada_max = 8
        elif vdificultad == 3:
            jugada_max = 7
        if tablero == 1:  # Posicion del tablero
            lugar = 7
        else:
            lugar = 0
        if elementos == 1:  # Tipo de elementos a utilizar (colores, letras, números o símbolos)
            Button(ven_juego, image=ImgColor1, command=lambda: colocar_color(ImgColor1)).grid(row=2, column=lugar)
            Button(ven_juego, image=ImgColor2, command=lambda: colocar_color(ImgColor2)).grid(row=3, column=lugar)
            Button(ven_juego, image=ImgColor3, command=lambda: colocar_color(ImgColor3)).grid(row=4, column=lugar)
            Button(ven_juego, image=ImgColor4, command=lambda: colocar_color(ImgColor4)).grid(row=5, column=lugar)
            Button(ven_juego, image=ImgColor5, command=lambda: colocar_color(ImgColor5)).grid(row=6, column=lugar)
            Button(ven_juego, image=ImgColor6, command=lambda: colocar_color(ImgColor6)).grid(row=7, column=lugar)
        elif elementos == 2:
            Button(ven_juego, text="A", font=("Tahoma", 22), width=2, command=lambda: colocar_color("A")).grid(row=2, column=lugar)
            Button(ven_juego, text="B", font=("Tahoma", 22), width=2, command=lambda: colocar_color("B")).grid(row=3, column=lugar)
            Button(ven_juego, text="C", font=("Tahoma", 22), width=2, command=lambda: colocar_color("C")).grid(row=4, column=lugar)
            Button(ven_juego, text="D", font=("Tahoma", 22), width=2, command=lambda: colocar_color("D")).grid(row=5, column=lugar)
            Button(ven_juego, text="E", font=("Tahoma", 22), width=2, command=lambda: colocar_color("E")).grid(row=6, column=lugar)
            Button(ven_juego, text="F", font=("Tahoma", 22), width=2, command=lambda: colocar_color("F")).grid(row=7, column=lugar)
        elif elementos == 3:
            Button(ven_juego, text="1", font=("Tahoma", 22), width=2, command=lambda: colocar_color("1")).grid(row=2, column=lugar)
            Button(ven_juego, text="2", font=("Tahoma", 22), width=2, command=lambda: colocar_color("2")).grid(row=3, column=lugar)
            Button(ven_juego, text="3", font=("Tahoma", 22), width=2, command=lambda: colocar_color("3")).grid(row=4, column=lugar)
            Button(ven_juego, text="4", font=("Tahoma", 22), width=2, command=lambda: colocar_color("4")).grid(row=5, column=lugar)
            Button(ven_juego, text="5", font=("Tahoma", 22), width=2, command=lambda: colocar_color("5")).grid(row=6, column=lugar)
            Button(ven_juego, text="6", font=("Tahoma", 22), width=2, command=lambda: colocar_color("6")).grid(row=7, column=lugar)
        elif elementos == 4:
            Button(ven_juego, text="@", font=("Tahoma", 22), width=2, command=lambda: colocar_color("@")).grid(row=2, column=lugar)
            Button(ven_juego, text="+", font=("Tahoma", 22), width=2, command=lambda: colocar_color("+")).grid(row=3, column=lugar)
            Button(ven_juego, text="&", font=("Tahoma", 22), width=2, command=lambda: colocar_color("&")).grid(row=4, column=lugar)
            Button(ven_juego, text="$", font=("Tahoma", 22), width=2, command=lambda: colocar_color("$")).grid(row=5, column=lugar)
            Button(ven_juego, text="!", font=("Tahoma", 22), width=2, command=lambda: colocar_color("!")).grid(row=6, column=lugar)
            Button(ven_juego, text="?", font=("Tahoma", 22), width=2, command=lambda: colocar_color("?")).grid(row=7, column=lugar)
        # Etiquetas invisibles de espacio para colocar los colores
        Label(ven_juego, width=6, height=2).grid(row=2, column=2)
        Label(ven_juego, width=6, height=2).grid(row=2, column=3)
        Label(ven_juego, width=6, height=2).grid(row=2, column=4)
        Label(ven_juego, width=6, height=2).grid(row=2, column=5)
        x = 1
        for i in range(2, jugada_max+1):  # Coloca las etiquetas de los numeros de jugadas posibles
            Label(ven_juego, width=5, height=3, text=str(x), font=("Tahoma", 10)).grid(row=i, column=1)
            x += 1
        Label(ven_juego, width=7, height=2).grid(row=2, column=6)
        # Radiobuttons
        Radiobutton(ven_juego, value=1, variable=seleccion_lugar).grid(row=1, column=2)  # Botones para decidir donde poner la opción presionada
        Radiobutton(ven_juego, value=2, variable=seleccion_lugar).grid(row=1, column=3)
        Radiobutton(ven_juego, value=3, variable=seleccion_lugar).grid(row=1, column=4)
        Radiobutton(ven_juego, value=4, variable=seleccion_lugar).grid(row=1, column=5)
        Label(ven_juego, height=1).grid(row=10, column=0)  # Etiqueta invisible
        tiempo = Label(ven_juego)  # Etiqueta del reloj
        tiempo.grid(row=12, column=0)
        timer()


def calificar():
    """
Salidas: Revisa si el juego terminó por gane, perdida, tiempo o sigue"""
    global numero_de_jugada, codigo, intento, coincidencias, apariciones, nombre, jugada_max, terminar, cancelar, segundos_config
    if numero_de_jugada == 2:  # Crea el codigo en la jugada inicial
        crear_codigo()
    revisar_colores()
    revisar_apariciones()
    if coincidencias != 4 and numero_de_jugada < jugada_max:  # Condiciones para que la partida siga
        if terminar is True:  # Terminó por tiempo
            if reloj == 4:
                messagebox.showinfo(title="Que pena", message="JUEGO TERMINADO: TIEMPO DE JUEGO EXCEDIDO")
                fin()
                terminar = False  # Asigna a las variables el valor iniciar para que en proximo juego se vuelva a jugar de la misma manera
                intento = ["", "", "", ""]  # Restaura los valores a sus valores iniciales para calcular la siguiente jugada
                coincidencias = 0
                apariciones = 0
            elif reloj == 3:
                respuesta_intento()
                messagebox.showinfo(title="Jugada terminada", message="JUGADA TERMINADA: TIEMPO EXCEDIDO")
                numero_de_jugada+=1
                terminar = False  # Asigna a las variables el valor iniciar para que en proximo juego se vuelva a jugar de la misma manera
                intento = ["", "", "", ""]  # Restaura los valores a sus valores iniciales para calcular la siguiente jugada
                coincidencias = 0
                apariciones = 0
                detener_reloj()  # Reinicia el reloj para que siga contando
                segundos.set(segundos_config)
                timer()
        else:
            if reloj == 3:  # Reinicia el reloj si se está jugando con cronómetro por jugada
                detener_reloj()
                segundos.set(segundos_config)
                timer()
            print(codigo)
            respuesta_intento()
            numero_de_jugada += 1
            intento = ["", "", "", ""]
            coincidencias = 0
            apariciones = 0
    elif coincidencias == 4:  # Termina por gane
        terminar = False
        respuesta_intento()
        intento = ["", "", "", ""]
        coincidencias = 0
        apariciones = 0
        messagebox.showinfo(title="Enhorabuena "+nombre, message="Has ganado la partida en "+str(numero_de_jugada-1)+" jugadas")
        fin()
    else:  # Termina por perdida
        if reloj == 3 and terminar == True:
            messagebox.showinfo(title="Jugada terminada", message="JUEGO TERMINADO: TIEMPO DE LA ÚLTIMA JUGADA EXCEDIDO")
            terminar = False
        else:
            respuesta_intento()
            messagebox.showinfo(title="Que pena", message="Has perdido")
        intento = ["", "", "", ""]
        coincidencias = 0
        apariciones = 0
        fin()


def respuesta_intento():
    """
Salidas: Coloca en la ventana la cantidad de aciertos y apariciones de la jugada actual"""
    global numero_de_jugada, coincidencias, apariciones
    stick = ("NW", "NE", "SE", "SW")  # Tupla para sacar un valor aleatorio y colocar la respuesta de la jugada
    cont = 0
    no_repetir = []  # Lleva las variables para que no se repitan en el random
    while cont != 4:
        if coincidencias > 0:  # Coloca las coincidencias
            respuesta = choice(stick)
            if respuesta in no_repetir:
                continue
            no_repetir += [respuesta]
            Label(ven_juego, image=acierto).grid(row=numero_de_jugada, column=6, sticky=respuesta)
            coincidencias -= 1
            cont += 1
        elif apariciones > 0:  # Coloca las apariciones
            respuesta = choice(stick)
            if respuesta in no_repetir:
                continue
            no_repetir += [respuesta]
            Label(ven_juego, image=aparicion).grid(row=numero_de_jugada, column=6, sticky=respuesta)
            apariciones -= 1
            cont += 1
        else:
            respuesta = choice(stick)  # Y si sobra coloca las etiquetas con el circulo vacío
            if respuesta in no_repetir:
                continue
            no_repetir += [respuesta]
            Label(ven_juego, image=nada).grid(row=numero_de_jugada, column=6, sticky=respuesta)
            cont += 1


def boton_fin():
    """
Salidas: Pregunta si quiere finalizar la partida"""
    pregunta = messagebox.askokcancel(title="Finalizar Partida", message="¿Estas seguro que quieres terminar la partida?")
    if pregunta == True:
        fin()
    else:
        pass

def fin():
    """
Salidas: Asigna, a todas las variables globales de las que depende el juego, su valor original para iniciar otra vez desde 0"""
    global codigo, numero_de_jugada, cancelar, segs, mins, hora
    codigo = ""
    numero_de_jugada = 2
    salir_juego()
    Label(ven_juego, width=1000, height=1000).place(x=0, y=0)
    jugador.set("")
    try:
        tiempo.after_cancel(cancelar)
    except:
        pass
    segs = 0
    mins = 0
    hora = 0
    

def revisar_apariciones():
    """
Salidas: Revisa las coincidencias y apariciones de la jugada actual que existen en comparacion al codigo a adivinar"""
    global codigo, intento, coincidencias, apariciones
    conta = 0
    temp = []
    x=0
    for i in range(0, 4):
        if intento[i] == "":
            continue
        elif intento[i] == codigo[i]:
            coincidencias+=1
    for i in range(0, 4):
        #conta=0
        if intento[i] == "":
            continue
        elif intento[i] in codigo:
            if intento[i] == codigo[i]:
                for j in codigo:  # Revisa todas las apariciones del digito en revision una unica vez
                    if j in temp: 
                        continue
                    else:
                        if j == intento[i]:
                            x=j
                            conta += 1  # Cuenta las apariciones de los digitos
                temp.append(x)
                apariciones = conta - coincidencias  # Le quita las coincidencias totales que hayan
            else:
                for j in codigo:
                    if j in temp:
                        continue
                    else:
                        if j == intento[i]:
                            x=j
                            conta += 1
                temp.append(x)
                apariciones = conta - coincidencias
                

def revisar_colores():
    """
Salidas: Dependiendo de los elementos seleccionados en la configuracion, cambia esos elementos por numeros para luego compararlos con el codigo inicial"""
    global intento
    for i in range(0, 4):
        if intento[i] is ImgColor1 or intento[i] is "A" or intento[i] is "1" or intento[i] is "@":
            intento[i] = "1"
        elif intento[i] is ImgColor2 or intento[i] is "B" or intento[i] is "2" or intento[i] is "+":
            intento[i] = "2"
        elif intento[i] is ImgColor3 or intento[i] is "C" or intento[i] is "3" or intento[i] is "&":
            intento[i] = "3"
        elif intento[i] is ImgColor4 or intento[i] is "D" or intento[i] is "4" or intento[i] is "$":
            intento[i] = "4"
        elif intento[i] is ImgColor5 or intento[i] is "E" or intento[i] is "5" or intento[i] is "!":
            intento[i] = "5"
        elif intento[i] is ImgColor6 or intento[i] is "F" or intento[i] is "6" or intento[i] is "?":
            intento[i] = "6"


def crear_codigo():
    """
Salidas: Asigna a la variable "codigo" la combinación con la que se va a jugar la partida"""
    global opciones, codigo, otros_codigos, cont_codigos, intento
    for i in range(4):
        elegido = choice(opciones)
        codigo += elegido
    if codigo in otros_codigos and cont_codigos <= 100:  # Esta condicion evita que el codigo se repita antes de 100 combinaciones
        crear_codigo()
    elif cont_codigos > 100:  # Si sobrepasa a 100 codigos, restaura los valores de las variables
        cont_codigos = 0
        otros_codigos = []
        crear_codigo()
    else:
        otros_codigos += [[codigo]]
        cont_codigos += 1


def colocar_color(valor):
    """
Salidas: Coloca la opción seleccionada en la posición presionada"""
    global seleccion_lugar, intento, numero_de_jugada
    s = seleccion_lugar.get()  # Recoge el valor que contiene el radiobutton elegido
    if s == 1:
        intento[0] = valor
        try:
            Label(ven_juego, width=40, height=50, image=valor).grid(row=numero_de_jugada, column=2)
        except:
            Label(ven_juego, text=valor, font=("Tahoma", 22), width=2).grid(row=numero_de_jugada, column=2)
    elif s == 2:
        intento[1] = valor
        try:
            Label(ven_juego, width=40, height=50, image=valor).grid(row=numero_de_jugada, column=3)
        except:
            Label(ven_juego, font=("Tahoma", 22), text=valor, width=2).grid(row=numero_de_jugada, column=3)
    elif s == 3:
        intento[2] = valor
        try:
            Label(ven_juego, width=40, height=50, image=valor).grid(row=numero_de_jugada, column=4)
        except:
            Label(ven_juego, font=("Tahoma", 22), text=valor, width=2).grid(row=numero_de_jugada, column=4)
    elif s == 4:
        intento[3] = valor
        try:
            Label(ven_juego, width=40, height=50, image=valor).grid(row=numero_de_jugada, column=5)
        except:
            Label(ven_juego, font=("Tahoma", 22), text=valor, width=2).grid(row=numero_de_jugada, column=5)


def guardar_configuracion():
    """
Salidas: Guarda las variables que utiliza la ventana de configuracion en el archivo para luego ser utilizadas"""
    global vdificultad, reloj, tablero, elementos, diccionario
    f = open("mastermind2016configuración.dat", "wb")
    if reloj == 1 or reloj == 2:
        diccionario = {"dificultad": vdificultad, "reloj": reloj, "tablero": tablero, "elementos": elementos}
    elif reloj == 3 or reloj == 4:
        diccionario = {"dificultad": vdificultad, "reloj": [reloj, segundos.get()], "tablero": tablero, "elementos": elementos}
    pickle.dump(diccionario, f)
    f.close()


def cargar_configuracion():
    """
Salidas: Saca los valores que tienen las llaves en el diccionario"""
    global vdificultad, reloj, tablero, elementos, segundos_config
    f = open("mastermind2016configuración.dat", "rb")  # Abre el archivo para leer los datos
    diccionario = pickle.load(f)  # Los guarda en un variable
    f.close()  # Cierra el archivo
    vdificultad = diccionario["dificultad"]  # Asigna a variables globales los valores que trae el archivo
    reloj = diccionario["reloj"]
    try:
        segundos_config = reloj[1]
        segundos.set(segundos_config)
        reloj = reloj[0]
    except:
        pass
    tablero = diccionario["tablero"]
    elementos = diccionario["elementos"]


def timer():
    """
Salidas: Un reloj dependiendo a lo escogido en configuracion (SÍ, NO, JUGADA O JUEGO)"""
    global segs, mins, hora, cancelar, reloj, terminar, tiempo, segundos_config, temp
    if reloj == 1:
        Label(ven_juego, text="|H-M-S|").grid(row=11, column=0)
        segs += 1  # Contador de segundos 
        if segs >= 60:
            segs = 0
            mins += 1
            if mins >= 60:
                mins = 0
                hora += 1
                if hora >= 3:
                    detener_reloj()
                    terminar = True
                    calificar()
        tiempo['text'] = str(hora)+" : "+str(mins)+" : "+str(segs)
        cancelar = tiempo.after(1000, timer)
    elif reloj == 2:
        pass
    elif reloj == 3:
        Label(ven_juego, text="|H-M-S|").grid(row=11, column=0)
        segs = segundos.get()
        while segs >= 60:  # Convierte los segundos a horas y minutos
            segs -= 60
            mins += 1
            if mins >= 60:
                mins -= 60
                hora += 1
                if hora >= 3:
                    mins = 59
                    segs = 59
                    hora = 2
                    break
        segs -= 1  # Una vez se tienen los datos en horas, minutos y segundos, se procede a restarlos para llegarlos a 0 (funciona como un temporizador)
        segundos.set(segs)
        if segs == -1:
            segs = 59
            mins -= 1
            if mins == -1:
                mins = 59
                hora -= 1
        if segs == 0 and mins == 0 and hora == 0:
            detener_reloj()
            terminar = True
            calificar()
        else:
            tiempo['text'] = str(hora)+" : "+str(mins)+" : "+str(segs)
            cancelar = tiempo.after(1000, timer)
    elif reloj == 4:
        if temp == segundos_config:
            temp = 0
            detener_reloj()
            terminar = True
            calificar()
        else:
            Label(ven_juego, text="|H-M-S|").grid(row=11, column=0)
            segs += 1
            temp += 1
            if segs >= 60:
                segs = 0
                mins += 1
                if mins >= 60:
                    mins = 0
                    hora += 1
                    if hora >= 3:
                        terminar = True
                        calificar()
            tiempo['text'] = str(hora) + " : " + str(mins) + " : " + str(segs)
            cancelar = tiempo.after(1000, timer)


def detener_reloj():
    """
Salidas: Detiene el reloj actual"""
    global cancelar, tiempo
    tiempo.after_cancel(cancelar)


# Funciones para globalizar los valores de los botones en configuración
def dificultad():
    global vdificultad
    vdificultad = seleccion_dificultad.get()


def config_reloj():
    global reloj
    reloj = seleccion_reloj.get()


def config_tablero():
    global tablero
    tablero = seleccion_tablero.get()


def elementos():
    global elementos
    elementos = seleccion_elementos.get()


def acerca_mm():
    """
Salidas: Muestra la informacion acerca del juego"""
    messagebox.showinfo(title="Acerda del programa",
                        message="Master Mind\nVersión: 1.0\nFecha de creación: 15 de Octubre, 2016\nAutor: Sergio Hidalgo Fonseca")


def manual_juego():
    """
Salidas: Abre el manual de usuario del juego"""
    popen("Sergio Hidalgo Fonseca - Manual de usuario mastermind.pdf")
    

# Interfaz
def mostrar_menu():
    Button(ven_mm, image=ImgRegresar, command=regresar_a_ventana).place(x=30, y=115)
    cargar_configuracion()
    ven_mm.deiconify()
    ven_principal.withdraw()


def mostrar_juego():
    global jugador
    Button(ven_juego, image=ImgRegresar, command=boton_fin).grid(row=0, column=0)  # Boton para regresar
    Button(ven_juego, text="Iniciar Juego", bg="pink", font=("Tahoma", 14), command=iniciar).place(x=230, y=600)  # Boton para iniciar el juego
    Entry(ven_juego, textvariable=jugador, width=35).place(x=145, y=690)  # Cuadro de texto para el nombre del jugador
    Label(ven_juego, text="Nombre del Jugador:", font=("Tahoma", 12)).place(x=145, y=665)
    Label(ven_juego, text="MASTER MIND", font=("Copperplate Gothic Bold", 20), fg="yellow", bg="green").place(x=65, y=10)
    ven_juego.deiconify()
    ven_mm.withdraw()


def mostrar_config():
    segundos.set(segundos_config)  # Coloca en el cuadro de texto el valor que contiene el reloj en el diccionario
    Button(ven_config, image=ImgRegresar, command=salir_config).place(x=0, y=0)  # Boton para regresar
    Label(ven_config, text="Dificultad", font=("Tahoma", 14)).place(x=10, y=70)
    Label(ven_config, image=ImgColor1).place(x=30, y=380)
    Label(ven_config, image=ImgColor2).place(x=30, y=430)
    Label(ven_config, image=ImgColor3).place(x=30, y=480)
    Label(ven_config, image=ImgColor4).place(x=30, y=530)
    Label(ven_config, image=ImgColor5).place(x=30, y=580)
    Label(ven_config, image=ImgColor6).place(x=30, y=630)
    Label(ven_config, text="A", font=("Tahoma", 23)).place(x=125, y=380)
    Label(ven_config, text="B", font=("Tahoma", 23)).place(x=125, y=430)
    Label(ven_config, text="C", font=("Tahoma", 23)).place(x=125, y=480)
    Label(ven_config, text="D", font=("Tahoma", 23)).place(x=125, y=530)
    Label(ven_config, text="E", font=("Tahoma", 23)).place(x=125, y=580)
    Label(ven_config, text="F", font=("Tahoma", 23)).place(x=125, y=630)
    Label(ven_config, text="1", font=("Tahoma", 23)).place(x=205, y=380)
    Label(ven_config, text="2", font=("Tahoma", 23)).place(x=205, y=430)
    Label(ven_config, text="3", font=("Tahoma", 23)).place(x=205, y=480)
    Label(ven_config, text="4", font=("Tahoma", 23)).place(x=205, y=530)
    Label(ven_config, text="5", font=("Tahoma", 23)).place(x=205, y=580)
    Label(ven_config, text="6", font=("Tahoma", 23)).place(x=205, y=630)
    Label(ven_config, text="@", font=("Tahoma", 23)).place(x=290, y=380)
    Label(ven_config, text="+", font=("Tahoma", 23)).place(x=290, y=430)
    Label(ven_config, text="&", font=("Tahoma", 23)).place(x=290, y=480)
    Label(ven_config, text="$", font=("Tahoma", 23)).place(x=290, y=530)
    Label(ven_config, text="!", font=("Tahoma", 23)).place(x=290, y=580)
    Label(ven_config, text="?", font=("Tahoma", 23)).place(x=290, y=630)
    ven_config.deiconify()
    ven_mm.withdraw()


def salir_config():
    ven_mm.deiconify()
    ven_config.withdraw()


def salir_juego():
    ven_mm.deiconify()
    ven_juego.withdraw()


# Ventana de inicio del juego
ven_mm = Toplevel(ven_principal)
ven_mm.geometry("372x720+400+200")
ven_mm.title("Menú Master Mind")
ven_mm.protocol("WM_DELETE_WINDOW", cerrar_todo)  # Hace que se cierre el programa completamente

# Ventana del juego
ven_juego = Toplevel(ven_principal)
ven_juego.geometry("400x720+400+200")
ven_juego.title("Master Mind")
ven_juego.protocol("WM_DELETE_WINDOW", cerrar_todo)  # Hace que se cierre el programa completamente

# Ventana de configuracion
ven_config = Toplevel(ven_principal)
ven_config.geometry("372x720+400+200")
ven_config.title("Configuración de Master Mind")
ven_config.protocol("WM_DELETE_WINDOW", cerrar_todo)  # Hace que se cierre el programa completamente
ven_config.withdraw()

# Cargar imágenes
ImgMM = PhotoImage(file="mastermind.gif")
ImgColor1 = PhotoImage(file="Color 1.gif")
ImgColor2 = PhotoImage(file="Color 2.gif")
ImgColor3 = PhotoImage(file="Color 3.gif")
ImgColor4 = PhotoImage(file="Color 4.gif")
ImgColor5 = PhotoImage(file="Color 5.gif")
ImgColor6 = PhotoImage(file="Color 6.gif")
acierto = PhotoImage(file="acierto.png")
aparicion = PhotoImage(file="aparicion.png")
nada = PhotoImage(file="nada.png")

# Etiquetas
Label(ven_principal, text="Master Mind", font=("Tahoma", 14), bg="sky blue").place(x=30, y=560)
Label(ven_mm, image=ImgBackground).place(x=0, y=0)
tiempo = Label(ven_juego)
tiempo.grid(row=11, column=0)

# Variables para widgets
jugador = StringVar()  # Variable para recoger el nombre del jugador
seleccion_lugar = IntVar()  # Variable para los radiobuttons para colocar un color

# Widgets varios para la ventana de configuración
seleccion_dificultad = IntVar()  # Variable para los radiobutton de dificultad
seleccion_reloj = IntVar()   # Variable para los radiobutton del reloj
segundos = IntVar()  # Variable para el cuadro de texto del reloj
seleccion_tablero = IntVar()   # Variable para los radiobutton de la posicion del tablero
seleccion_elementos = IntVar()   # Variable para los radiobutton de los elementos
Label(ven_config, text="_____________________________________________________________________").place(x=10, y=110)
Label(ven_config, text="_____________________________________________________________________").place(x=10, y=250)
Label(ven_config, text="_____________________________________________________________________").place(x=10, y=310)
Radiobutton(ven_config, text="Fácil (8 jugadas)", value=1, variable=seleccion_dificultad, command=dificultad).place(x=95, y=55)
Radiobutton(ven_config, text="Medio (7 jugadas)", value=2, variable=seleccion_dificultad, command=dificultad).place(x=95, y=75)
Radiobutton(ven_config, text="Difícil (6 jugadas)", value=3, variable=seleccion_dificultad, command=dificultad).place(x=95, y=95)
Label(ven_config, text="Reloj", font=("Tahoma", 14)).place(x=10, y=165)
Radiobutton(ven_config, text="Sí", value=1, variable=seleccion_reloj, command=config_reloj).place(x=60, y=135)
Radiobutton(ven_config, text="No", value=2, variable=seleccion_reloj, command=config_reloj).place(x=60, y=155)
Radiobutton(ven_config, text="Cronómetro por jugada", value=3, variable=seleccion_reloj, command=config_reloj).place(x=60, y=175)
Radiobutton(ven_config, text="Cronómetro por juego", value=4, variable=seleccion_reloj, command=config_reloj).place(x=60, y=195)
Label(ven_config, text="Nota: Si escogió un cronómetro\nindique el tiempo que desea (en segundos)").place(x=80, y=220)
Entry(ven_config, textvariable=segundos, width=10).place(x=10, y=230)
Label(ven_config, text="Posicion del tablero", font=("Tahoma", 14)).place(x=10, y=280)
Radiobutton(ven_config, text="Derecha", value=1, variable=seleccion_tablero, command=config_tablero).place(x=180, y=275)
Radiobutton(ven_config, text="Izquierda", value=2, variable=seleccion_tablero, command=config_tablero).place(x=180, y=295)
Label(ven_config, text="Panel de elementos", font=("Tahoma", 14)).place(x=10, y=330)
Radiobutton(ven_config, text="Colores", value=1, variable=seleccion_elementos, command=elementos).place(x=20, y=360)
Radiobutton(ven_config, text="Letras", value=2, variable=seleccion_elementos, command=elementos).place(x=105, y=360)
Radiobutton(ven_config, text="Números", value=3, variable=seleccion_elementos, command=elementos).place(x=175, y=360)
Radiobutton(ven_config, text="Símbolos", value=4, variable=seleccion_elementos, command=elementos).place(x=260, y=360)
Button(ven_config, image=ImgAceptar, command=guardar_configuracion).place(x=310, y=660)

# Botones
btnMM = Button(ven_principal, image=ImgMM, command=mostrar_menu).place(x=50, y=490)
btnIniciar = Button(ven_mm, text="INICIAR JUEGO", font=("Tahoma", 18), width=15, height=2, command=mostrar_juego).place(x=80, y=180)
btnConfig = Button(ven_mm, text="CONFIGURACIÓN", font=("Tahoma", 18), width=15, height=2, command=mostrar_config).place(x=80, y=280)
btnAyuda = Button(ven_mm, text="AYUDA", font=("Tahoma", 18), width=15, height=2, command=manual_juego).place(x=80, y=380)
btnAcercaDe = Button(ven_mm, text="ACERCA DE", font=("Tahoma", 18), width=15, height=2, command=acerca_mm).place(x=80, y=480)


ven_mm.withdraw()  # Oculta las ventanas
ven_juego.withdraw()

ven_principal.mainloop()
